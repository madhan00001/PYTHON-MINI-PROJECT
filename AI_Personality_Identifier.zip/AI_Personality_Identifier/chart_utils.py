"""
chart_utils.py
--------------
Builds a Matplotlib radar (spider) chart of the user's five trait
scores. Used both by the results dashboard (embedded live in the
CustomTkinter window) and by the PDF report generator (rendered to a
temporary PNG and inserted into the document).
"""

import matplotlib
matplotlib.use("Agg")  # safe default; UI embedding overrides per-figure via FigureCanvasTkAgg

import numpy as np
import matplotlib.pyplot as plt

from personality_engine import TRAIT_NAMES, TRAIT_KEYS

PRIMARY = "#7c6bf2"
GRID = "#3a3f63"
TEXT = "#c9cdec"


def build_radar_figure(scores: dict, dark: bool = True, figsize=(4.4, 4.4)):
    """Return a Matplotlib Figure with a radar chart of the trait scores."""
    labels = [TRAIT_NAMES[k] for k in TRAIT_KEYS]
    values = [scores.get(k, 0) for k in TRAIT_KEYS]

    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    values_closed = values + values[:1]
    angles_closed = angles + angles[:1]

    face = "#181c2e" if dark else "#ffffff"
    text_color = TEXT if dark else "#22243a"
    grid_color = GRID if dark else "#d7dae8"

    fig = plt.Figure(figsize=figsize, dpi=100, facecolor=face)
    ax = fig.add_subplot(111, polar=True)
    ax.set_facecolor(face)

    ax.plot(angles_closed, values_closed, color=PRIMARY, linewidth=2)
    ax.fill(angles_closed, values_closed, color=PRIMARY, alpha=0.30)

    ax.set_xticks(angles)
    ax.set_xticklabels(labels, color=text_color, fontsize=9)
    ax.set_ylim(0, 100)
    ax.set_yticks([20, 40, 60, 80, 100])
    ax.set_yticklabels(["20", "40", "60", "80", "100"], color=text_color, fontsize=7)
    ax.grid(color=grid_color, linewidth=0.6)
    ax.spines["polar"].set_color(grid_color)

    fig.tight_layout()
    return fig


def save_radar_png(scores: dict, output_path: str, dark: bool = False) -> str:
    """Render the radar chart straight to a PNG file (used by the PDF report)."""
    fig = build_radar_figure(scores, dark=dark, figsize=(4.2, 4.2))
    fig.savefig(output_path, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return output_path
