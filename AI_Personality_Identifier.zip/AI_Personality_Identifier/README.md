# 🤖 AI Personality Identifier

A modern, desktop AI-style personality analysis app built with **Python + CustomTkinter**.
It walks the user through a 15-question interactive quiz, analyzes their answers with a
transparent, explainable scoring engine, and produces a personalized personality
dashboard, chatbot, history log and downloadable PDF report.

> **Disclaimer:** All results are an AI-generated *estimate* for self-reflection and
> entertainment, based only on the user's quiz answers. This is **not** a medical,
> clinical or psychological diagnosis, and the app never claims to be one.

---

## 1. Project Structure

```
AI_Personality_Identifier/
│
├── main.py                 # App entry point / screen controller
├── config.py                # Colors, fonts, paths, app + optional AI-API settings
├── questions.py              # Interests, 15 questions, personality type catalogue
├── personality_engine.py     # Raw answers -> normalized 0-100 trait scores
├── ai_analyzer.py            # Trait scores -> personality type, strengths, etc.
├── chatbot.py                 # "Ask AI" — rule-based, with optional API fallback
├── pdf_report.py              # ReportLab PDF report generator
├── chart_utils.py             # Matplotlib radar chart (UI + PDF)
├── database.py                 # SQLite persistence layer
│
├── ui/
│   ├── welcome.py             # Screen 1
│   ├── profile.py              # Screen 2 — name entry
│   ├── interests.py             # Screen 3 — interest selection
│   ├── quiz.py                   # Screen 4 — 15 questions, one at a time
│   ├── analyzing.py               # Screen 5 — animated AI analysis
│   ├── results.py                  # Screens 6/7 — result dashboard
│   ├── history.py                   # Screen 8 — test history
│   └── chatbot_ui.py                 # "Ask AI" chat screen
│
├── assets/                    # icons/images (optional, currently emoji-only)
├── database/personality.db     # created automatically on first run
├── reports/                     # generated PDF reports land here
└── requirements.txt
```

The app follows this flow:

```
Welcome → Name → Interests → 15 Questions → AI Analysis (animated)
        → Result Dashboard → (Ask AI / Download PDF / Retake / History)
```

---

## 2. Installing Dependencies

Requires **Python 3.10+** (uses modern type-hint syntax like `str | None`).

```bash
cd AI_Personality_Identifier
python -m venv venv

# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate

pip install -r requirements.txt
```

`requirements.txt` installs:
- `customtkinter` — modern themed GUI widgets on top of Tkinter
- `reportlab` — PDF report generation
- `matplotlib` — the radar/spider chart on the results dashboard and in the PDF

`sqlite3` and `tkinter` ship with the standard Python installer on Windows/macOS.
On Linux, if `tkinter` is missing, install it via your package manager first, e.g.:

```bash
sudo apt install python3-tk        # Debian/Ubuntu
sudo dnf install python3-tkinter   # Fedora
```

---

## 3. Creating the Project Folders

If you're copying files manually rather than downloading the whole project, create
this folder layout before running the app:

```bash
mkdir -p AI_Personality_Identifier/ui
mkdir -p AI_Personality_Identifier/assets/icons
mkdir -p AI_Personality_Identifier/assets/images
mkdir -p AI_Personality_Identifier/database
mkdir -p AI_Personality_Identifier/reports
```

`database/personality.db` and any PDF files in `reports/` are created automatically
the first time you run the app or download a report — you don't need to create them
by hand.

---

## 4. Running the Application

```bash
python main.py
```

A window opens on the Welcome screen. Click **Get Started**, enter your name, pick
your interests, answer all 15 questions, and the app will animate through the AI
analysis before showing your personalized dashboard.

---

## 5. How the Personality Scoring Algorithm Works

1. **Answer weighting** — every answer option in `questions.py` carries small integer
   deltas across five Big-Five-style traits: **O**penness, **C**onscientiousness,
   **E**xtraversion, **A**greeableness, **E**motional **S**tability. For example,
   picking *"Start conversations"* adds `+3` to Extraversion and `+1` to Agreeableness.

2. **Normalization** — `personality_engine.py` computes, for each trait, the
   theoretical minimum and maximum total across all 15 questions (i.e. "what if the
   user always picked the lowest/highest-scoring option for this trait"). Your raw
   total is then rescaled linearly onto a 0–100 scale. This makes the algorithm fully
   data-driven — if you edit or add questions, the ranges recompute automatically.

3. **Categorical tagging** — some options also carry tags like
   `"decision": "analytical"` or `"risk": "high"`. The most frequent tag per category
   becomes your dominant decision-making style, social style, risk tolerance,
   motivation, work preference and learning preference.

4. **Personality type matching** — `ai_analyzer.py` defines 8 personality types
   (Creative Explorer, Analytical Thinker, Ambitious Leader, Social Connector, Calm
   Strategist, Imaginative Creator, Curious Scientist, Innovative Problem Solver),
   each with an ideal trait "signature" (0–100 per trait). Your normalized scores are
   compared to every signature using **Euclidean distance**, and the closest match is
   selected as your personality type.

5. **Personalization** — strengths, growth areas, description and recommended
   activities combine the matched type's template content with a couple of lines
   generated from your single strongest/weakest trait and your selected + inferred
   interests, so no two results read identically even within the same type.

This whole pipeline is deterministic and explainable — nothing here is a black box
neural network, which keeps it appropriate for a project demo and easy to reason
about or extend.

---

## 6. Configuring an Optional AI API (for the chatbot)

The **"Ask AI about your personality"** chatbot works fully offline out of the box
using a local rule-based fallback (`chatbot.py`), matching your question against
keywords and answering using your stored result as context.

To upgrade it to use a real LLM instead, set two environment variables before
launching the app:

```bash
# Anthropic (Claude)
export AI_PROVIDER=anthropic
export ANTHROPIC_API_KEY="sk-ant-..."

# OR OpenAI
export AI_PROVIDER=openai
export OPENAI_API_KEY="sk-..."
```

On Windows PowerShell, use `$env:AI_PROVIDER = "anthropic"` etc.

If no key is configured, or the request fails for any reason (no internet, invalid
key, rate limit...), the chatbot **silently falls back** to the local rule-based
engine — the app never crashes because of a missing or failed API call.

---

## 7. How the SQLite Database Works

`database.py` wraps a single SQLite file at `database/personality.db` with one table,
`results`, storing (per completed test): user name, selected interests, all 15 raw
answers, computed trait scores, personality type, strengths, growth areas,
recommendations, description and a timestamp — each as JSON where appropriate.

Key methods on `DatabaseManager`:
- `save_result(result)` — insert a completed test, returns its row id
- `get_history(user_name=None)` — list all saved tests, newest first
- `get_result(id)` / `delete_result(id)` — fetch or remove a single test
- `get_previous_result(user_name, exclude_id)` — used to power the "compare with
  previous result" feature on the dashboard

All database calls are wrapped in `try/except sqlite3.Error` and re-raised as a
friendly `DatabaseError`, which the UI catches and reports without crashing the app.

---

## 8. How PDF Reports Are Generated

Clicking **📄 Download PDF** on the results dashboard calls `pdf_report.generate_pdf()`,
which uses **ReportLab's Platypus** layout engine to build a multi-section document:
header, personality overview, a trait-score table (with a text-bar visualization),
an embedded **Matplotlib radar chart** (via `chart_utils.py`), strengths, growth
areas, recommended activities, and a disclaimer footer. The finished PDF is saved to
`reports/<name>_<timestamp>.pdf`, and its full path is shown in a confirmation dialog.

If PDF generation fails for any reason (disk permissions, invalid characters, etc.),
a `PDFReportError` is caught by the UI and shown as a friendly error dialog instead of
crashing the app.

---

## 9. Error Handling Summary

The app is built to **never crash** on user error:
- Empty name / no interests selected → inline warning, blocks navigation
- Unanswered question → inline warning on the "Next" button
- Database unavailable → app still runs, results just aren't saved to history
- PDF generation failure → error dialog, user can retry
- Missing/invalid AI API key → chatbot silently falls back to rule-based answers
- Any unexpected exception during analysis → caught, shown as a message box, user is
  returned to the quiz to retry

---

## 10. Technologies Used

- **Python 3** with clean, modular Object-Oriented design
- **CustomTkinter** — modern themed GUI (dark theme, rounded cards, hover effects,
  animated progress bars)
- **SQLite** (`sqlite3`, stdlib) — local persistence & history
- **Matplotlib** — radar/spider chart of trait scores (dashboard + PDF)
- **ReportLab** — professional PDF report generation
- Optional **Anthropic / OpenAI API** integration for the "Ask AI" chatbot, with a
  built-in offline rule-based fallback so the app always works
