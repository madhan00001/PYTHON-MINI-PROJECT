"""ui/quiz.py -- Screen 4: 15 interactive questions, one per screen."""

import customtkinter as ctk
import config
from questions import QUESTIONS


class AnswerCard(ctk.CTkButton):
    def __init__(self, parent, option, index, on_select):
        self.index = index
        self.on_select = on_select
        super().__init__(
            parent,
            text=f"{option['emoji']}   {option['text']}",
            font=config.FONTS["body_bold"],
            anchor="w",
            height=58, corner_radius=16,
            fg_color=config.COLORS["surface_dark"],
            hover_color=config.COLORS["card_dark"],
            border_width=2, border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"],
            command=self._select,
        )

    def _select(self):
        self.on_select(self.index)

    def set_selected(self, is_selected: bool):
        if is_selected:
            self.configure(
                fg_color=config.COLORS["primary"],
                border_color=config.COLORS["primary"],
                text_color="#ffffff",
            )
        else:
            self.configure(
                fg_color=config.COLORS["surface_dark"],
                border_color=config.COLORS["border_dark"],
                text_color=config.COLORS["text_dark"],
            )


class QuizScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller
        self.answer_cards: list[AnswerCard] = []
        self.selected_index = None

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=60, pady=(36, 8))

        self.progress_label = ctk.CTkLabel(
            top, text="Question 1 of 15", font=config.FONTS["body_bold"],
            text_color=config.COLORS["muted_dark"],
        )
        self.progress_label.pack(anchor="w")

        self.progress_bar = ctk.CTkProgressBar(
            top, width=760, height=14, corner_radius=7,
            progress_color=config.COLORS["primary"], fg_color=config.COLORS["surface_dark"],
        )
        self.progress_bar.set(1 / config.TOTAL_QUESTIONS)
        self.progress_bar.pack(pady=(8, 0), fill="x")

        self.question_label = ctk.CTkLabel(
            self, text="", font=config.FONTS["heading"], wraplength=760,
            text_color=config.COLORS["text_dark"], justify="left",
        )
        self.question_label.pack(pady=(28, 18), padx=60, anchor="w")

        self.options_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.options_frame.pack(fill="both", expand=True, padx=60)

        self.error_label = ctk.CTkLabel(
            self, text="", font=config.FONTS["small"], text_color=config.COLORS["danger"],
        )
        self.error_label.pack(pady=(4, 0))

        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(pady=20)

        self.back_btn = ctk.CTkButton(
            footer, text="← Back", font=config.FONTS["body"], width=120, height=46,
            corner_radius=23, fg_color="transparent", border_width=2,
            border_color=config.COLORS["border_dark"], text_color=config.COLORS["text_dark"],
            hover_color=config.COLORS["surface_dark"],
            command=self._go_back,
        )
        self.back_btn.pack(side="left", padx=8)

        self.next_btn = ctk.CTkButton(
            footer, text="Next  →", font=config.FONTS["button"], width=200, height=46,
            corner_radius=23, fg_color=config.COLORS["primary"],
            hover_color=config.COLORS["primary_hover"],
            command=self._go_next,
        )
        self.next_btn.pack(side="left", padx=8)

    # ------------------------------------------------------------------
    def on_show(self):
        self._render_question()

    def _render_question(self):
        state = self.controller.state_data
        idx = state.current_question_index
        question = QUESTIONS[idx]

        self.progress_label.configure(text=f"Question {idx + 1} of {config.TOTAL_QUESTIONS}")
        self.progress_bar.set((idx + 1) / config.TOTAL_QUESTIONS)
        self.question_label.configure(text=question["text"])
        self.error_label.configure(text="")

        for widget in self.options_frame.winfo_children():
            widget.destroy()
        self.answer_cards = []

        self.selected_index = state.answers.get(question["id"])

        for i, option in enumerate(question["options"]):
            card = AnswerCard(self.options_frame, option, i, self._select_option)
            card.pack(fill="x", pady=6)
            card.set_selected(i == self.selected_index)
            self.answer_cards.append(card)

        self.back_btn.configure(text="← Back" if idx > 0 else "← Interests")
        self.next_btn.configure(text="Finish ✓" if idx == config.TOTAL_QUESTIONS - 1 else "Next  →")

    def _select_option(self, index):
        self.selected_index = index
        for i, card in enumerate(self.answer_cards):
            card.set_selected(i == index)
        self.error_label.configure(text="")

        state = self.controller.state_data
        question = QUESTIONS[state.current_question_index]
        state.answers[question["id"]] = index

    def _go_next(self):
        if self.selected_index is None:
            self.error_label.configure(text="⚠️ Please select an answer to continue.")
            return

        state = self.controller.state_data
        if state.current_question_index < config.TOTAL_QUESTIONS - 1:
            state.current_question_index += 1
            self._render_question()
        else:
            self.controller.show_frame("analyzing")

    def _go_back(self):
        state = self.controller.state_data
        if state.current_question_index > 0:
            state.current_question_index -= 1
            self._render_question()
        else:
            self.controller.show_frame("interests")
