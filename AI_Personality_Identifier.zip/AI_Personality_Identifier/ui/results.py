"""ui/results.py -- Screens 6 & 7: Result dashboard / detailed report."""

import os
import tkinter.messagebox as messagebox

import customtkinter as ctk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import config
from questions import PERSONALITY_TYPES
from personality_engine import TRAIT_NAMES
from pdf_report import generate_pdf, PDFReportError
from chart_utils import build_radar_figure


TRAIT_COLORS = {
    "O": config.COLORS["primary"],
    "C": config.COLORS["secondary"],
    "E": config.COLORS["accent"],
    "A": config.COLORS["warning"],
    "ES": "#4fc3f7",
}


class ScoreBar(ctk.CTkFrame):
    """A single labeled, animated horizontal progress bar for one trait."""

    def __init__(self, parent, label, color):
        super().__init__(parent, fg_color="transparent")
        self.color = color

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x")
        self.name_label = ctk.CTkLabel(
            header, text=label, font=config.FONTS["body_bold"],
            text_color=config.COLORS["text_dark"],
        )
        self.name_label.pack(side="left")
        self.value_label = ctk.CTkLabel(
            header, text="0%", font=config.FONTS["body_bold"], text_color=color,
        )
        self.value_label.pack(side="right")

        self.bar = ctk.CTkProgressBar(
            self, height=14, corner_radius=7, progress_color=color,
            fg_color=config.COLORS["surface_dark"],
        )
        self.bar.set(0)
        self.bar.pack(fill="x", pady=(6, 14))

        self._target = 0
        self._current = 0.0
        self._after_id = None

    def animate_to(self, target_percent: int):
        self._target = target_percent / 100
        self._current = 0.0
        self.value_label.configure(text="0%")
        if self._after_id:
            self.after_cancel(self._after_id)
        self._step()

    def _step(self):
        remaining = self._target - self._current
        if abs(remaining) < 0.01:
            self._current = self._target
            self.bar.set(self._current)
            self.value_label.configure(text=f"{round(self._current * 100)}%")
            return
        self._current += remaining * 0.25
        self.bar.set(self._current)
        self.value_label.configure(text=f"{round(self._current * 100)}%")
        self._after_id = self.after(20, self._step)


class ResultsScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller
        self.score_bars: dict[str, ScoreBar] = {}

        # ---- Top bar with navigation buttons --------------------------
        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", padx=30, pady=(20, 0))

        ctk.CTkButton(
            top_bar, text="📜 History", width=110, height=38, corner_radius=19,
            fg_color="transparent", border_width=2, border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"], hover_color=config.COLORS["surface_dark"],
            command=lambda: controller.show_frame("history"),
        ).pack(side="left")

        ctk.CTkButton(
            top_bar, text="🔄 Retake Test", width=140, height=38, corner_radius=19,
            fg_color="transparent", border_width=2, border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"], hover_color=config.COLORS["surface_dark"],
            command=lambda: controller.start_new_test(),
        ).pack(side="right", padx=(8, 0))

        ctk.CTkButton(
            top_bar, text="💬 Ask AI", width=120, height=38, corner_radius=19,
            fg_color=config.COLORS["primary"], hover_color=config.COLORS["primary_hover"],
            command=lambda: controller.show_frame("chatbot"),
        ).pack(side="right", padx=(8, 0))

        ctk.CTkButton(
            top_bar, text="📄 Download PDF", width=150, height=38, corner_radius=19,
            fg_color=config.COLORS["secondary"], hover_color="#33c8a3",
            text_color="#0f1220",
            command=self._download_pdf,
        ).pack(side="right", padx=(8, 0))

        # ---- Scrollable content -----------------------------------------
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=30, pady=16)

        self.badge_label = ctk.CTkLabel(
            self.scroll, text="", font=("Segoe UI Emoji", 46),
        )
        self.badge_label.pack(pady=(6, 0))

        self.type_label = ctk.CTkLabel(
            self.scroll, text="", font=config.FONTS["title"],
            text_color=config.COLORS["text_dark"],
        )
        self.type_label.pack()

        self.subtitle_label = ctk.CTkLabel(
            self.scroll, text="AI-generated personality estimate — not a diagnosis",
            font=config.FONTS["small"], text_color=config.COLORS["muted_dark"],
        )
        self.subtitle_label.pack(pady=(2, 20))

        # Trait score card
        self.score_card = self._make_card("📊 Your Personality Scores")
        for key, name in TRAIT_NAMES.items():
            bar = ScoreBar(self.score_card, name, TRAIT_COLORS.get(key, config.COLORS["primary"]))
            bar.pack(fill="x", padx=20)
            self.score_bars[key] = bar

        self.compare_label = ctk.CTkLabel(
            self.score_card, text="", font=config.FONTS["small"],
            text_color=config.COLORS["muted_dark"], justify="left",
        )
        self.compare_label.pack(anchor="w", padx=20, pady=(0, 14))

        # Radar chart card (Matplotlib)
        self.chart_card = self._make_card("📈 Personality Chart")
        self.chart_holder = ctk.CTkFrame(self.chart_card, fg_color="transparent")
        self.chart_holder.pack(pady=(0, 16))
        self.chart_canvas_widget = None

        # Interests card
        self.interests_card = self._make_card("🎯 Your Interests")
        self.interests_label = ctk.CTkLabel(
            self.interests_card, text="", font=config.FONTS["body"],
            text_color=config.COLORS["text_dark"], wraplength=760, justify="left",
        )
        self.interests_label.pack(anchor="w", padx=20, pady=(0, 16))

        # Description card
        self.description_card = self._make_card("🧠 Personality Description")
        self.description_label = ctk.CTkLabel(
            self.description_card, text="", font=config.FONTS["body"],
            text_color=config.COLORS["text_dark"], wraplength=760, justify="left",
        )
        self.description_label.pack(anchor="w", padx=20, pady=(0, 16))

        # Strengths / growth side-by-side
        two_col = ctk.CTkFrame(self.scroll, fg_color="transparent")
        two_col.pack(fill="x", pady=(0, 16))
        two_col.grid_columnconfigure(0, weight=1)
        two_col.grid_columnconfigure(1, weight=1)

        strengths_card = ctk.CTkFrame(
            two_col, fg_color=config.COLORS["surface_dark"], corner_radius=18,
        )
        strengths_card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        ctk.CTkLabel(
            strengths_card, text="💪 Your Strengths", font=config.FONTS["subheading"],
            text_color=config.COLORS["text_dark"],
        ).pack(anchor="w", padx=20, pady=(16, 8))
        self.strengths_label = ctk.CTkLabel(
            strengths_card, text="", font=config.FONTS["body"],
            text_color=config.COLORS["text_dark"], wraplength=340, justify="left",
        )
        self.strengths_label.pack(anchor="w", padx=20, pady=(0, 16))

        growth_card = ctk.CTkFrame(
            two_col, fg_color=config.COLORS["surface_dark"], corner_radius=18,
        )
        growth_card.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        ctk.CTkLabel(
            growth_card, text="⚠️ Growth Areas", font=config.FONTS["subheading"],
            text_color=config.COLORS["text_dark"],
        ).pack(anchor="w", padx=20, pady=(16, 8))
        self.growth_label = ctk.CTkLabel(
            growth_card, text="", font=config.FONTS["body"],
            text_color=config.COLORS["text_dark"], wraplength=340, justify="left",
        )
        self.growth_label.pack(anchor="w", padx=20, pady=(0, 16))

        # Recommendations card
        self.rec_card = self._make_card("💡 Recommended Activities")
        self.rec_label = ctk.CTkLabel(
            self.rec_card, text="", font=config.FONTS["body"],
            text_color=config.COLORS["text_dark"], wraplength=760, justify="left",
        )
        self.rec_label.pack(anchor="w", padx=20, pady=(0, 16))

        disclaimer = ctk.CTkLabel(
            self.scroll,
            text="This report is an AI-generated estimate for self-reflection only "
                 "and is not a medical or psychological diagnosis.",
            font=config.FONTS["small"], text_color=config.COLORS["muted_dark"],
            wraplength=760, justify="center",
        )
        disclaimer.pack(pady=(6, 20))

    # ------------------------------------------------------------------
    def _make_card(self, title):
        card = ctk.CTkFrame(self.scroll, fg_color=config.COLORS["surface_dark"], corner_radius=18)
        card.pack(fill="x", pady=(0, 16))
        ctk.CTkLabel(
            card, text=title, font=config.FONTS["subheading"],
            text_color=config.COLORS["text_dark"],
        ).pack(anchor="w", padx=20, pady=(16, 10))
        return card

    # ------------------------------------------------------------------
    def on_show(self):
        state = self.controller.state_data
        result = state.result
        if not result:
            self.controller.show_frame("welcome")
            return

        type_data = PERSONALITY_TYPES.get(result["personality_type"], {})
        self.badge_label.configure(text=type_data.get("emoji", "🌟"))
        self.type_label.configure(text=result["personality_name"])

        for key, bar in self.score_bars.items():
            bar.animate_to(result["scores"].get(key, 0))

        interests_text = "  •  ".join(
            i.replace("_", " ").title() for i in result["interests"]
        )
        self.interests_label.configure(text=interests_text or "No specific interests recorded.")

        self.description_label.configure(text=result["description"])

        self.strengths_label.configure(
            text="\n".join(f"✓  {s}" for s in result["strengths"])
        )
        self.growth_label.configure(
            text="\n".join(f"•  {g}" for g in result["growth_areas"])
        )
        self.rec_label.configure(
            text="\n".join(f"→  {r}" for r in result["recommendations"])
        )

        self._show_comparison(result)
        self._render_chart(result)

    def _render_chart(self, result):
        if self.chart_canvas_widget is not None:
            self.chart_canvas_widget.get_tk_widget().destroy()
            self.chart_canvas_widget = None
        try:
            fig = build_radar_figure(result["scores"], dark=True, figsize=(4.2, 4.2))
            canvas = FigureCanvasTkAgg(fig, master=self.chart_holder)
            canvas.draw()
            widget = canvas.get_tk_widget()
            widget.configure(bg=config.COLORS["surface_dark"], highlightthickness=0)
            widget.pack()
            self.chart_canvas_widget = canvas
        except Exception:
            # Chart is a visual bonus -- never let it crash the results screen.
            ctk.CTkLabel(
                self.chart_holder, text="(Chart unavailable)",
                font=config.FONTS["small"], text_color=config.COLORS["muted_dark"],
            ).pack()

    def _show_comparison(self, result):
        self.compare_label.configure(text="")
        db = self.controller.db
        if db is None:
            return
        try:
            previous = db.get_previous_result(result["user_name"], exclude_id=result.get("id"))
        except Exception:
            previous = None

        if not previous:
            return

        diffs = []
        for key, name in TRAIT_NAMES.items():
            old_val = previous["scores"].get(key, 0)
            new_val = result["scores"].get(key, 0)
            delta = new_val - old_val
            if delta == 0:
                continue
            arrow = "▲" if delta > 0 else "▼"
            diffs.append(f"{name} {arrow} {abs(delta)}%")

        if diffs:
            self.compare_label.configure(
                text="📈 Compared to your previous test: " + ", ".join(diffs)
            )
        else:
            self.compare_label.configure(
                text="📈 Your scores are identical to your previous test."
            )

    # ------------------------------------------------------------------
    def _download_pdf(self):
        result = self.controller.state_data.result
        if not result:
            return
        try:
            path = generate_pdf(result)
        except PDFReportError as exc:
            messagebox.showerror("PDF Error", str(exc))
            return
        messagebox.showinfo(
            "Report Saved",
            f"Your personality report has been saved to:\n{os.path.abspath(path)}",
        )
