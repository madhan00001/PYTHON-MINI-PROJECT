"""ui/history.py -- Screen 8: previous test history."""

import tkinter.messagebox as messagebox

import customtkinter as ctk
import config
from database import DatabaseError


class HistoryScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller

        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", padx=30, pady=(24, 10))

        ctk.CTkButton(
            top_bar, text="← Back", width=100, height=38, corner_radius=19,
            fg_color="transparent", border_width=2, border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"], hover_color=config.COLORS["surface_dark"],
            command=self._go_back,
        ).pack(side="left")

        ctk.CTkLabel(
            top_bar, text="📜 Test History", font=config.FONTS["heading"],
            text_color=config.COLORS["text_dark"],
        ).pack(side="left", padx=20)

        ctk.CTkButton(
            top_bar, text="🚀 New Test", width=130, height=38, corner_radius=19,
            fg_color=config.COLORS["primary"], hover_color=config.COLORS["primary_hover"],
            command=lambda: controller.start_new_test(),
        ).pack(side="right")

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=30, pady=10)

        self.empty_label = ctk.CTkLabel(
            self.scroll, text="No tests taken yet. Start your first personality test!",
            font=config.FONTS["body"], text_color=config.COLORS["muted_dark"],
        )

    # ------------------------------------------------------------------
    def on_show(self):
        for widget in self.scroll.winfo_children():
            widget.destroy()

        db = self.controller.db
        if db is None:
            self.empty_label.configure(text="⚠️ History unavailable — database not connected.")
            self.empty_label.pack(pady=40)
            return

        try:
            history = db.get_history()
        except DatabaseError as exc:
            messagebox.showerror("Database Error", str(exc))
            history = []

        if not history:
            self.empty_label.configure(
                text="No tests taken yet. Start your first personality test!"
            )
            self.empty_label.pack(pady=40)
            return

        for entry in history:
            self._build_row(entry)

    def _build_row(self, entry):
        row = ctk.CTkFrame(self.scroll, fg_color=config.COLORS["surface_dark"], corner_radius=16)
        row.pack(fill="x", pady=6)

        info = ctk.CTkFrame(row, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True, padx=18, pady=12)

        ctk.CTkLabel(
            info, text=f"{entry['personality_name']}  —  {entry['user_name']}",
            font=config.FONTS["body_bold"], text_color=config.COLORS["text_dark"],
            anchor="w",
        ).pack(anchor="w")

        interests_preview = ", ".join(i.replace("_", " ").title() for i in entry["interests"][:4])
        ctk.CTkLabel(
            info, text=f"{entry['created_at']}   •   {interests_preview}",
            font=config.FONTS["small"], text_color=config.COLORS["muted_dark"], anchor="w",
        ).pack(anchor="w", pady=(4, 0))

        btns = ctk.CTkFrame(row, fg_color="transparent")
        btns.pack(side="right", padx=14, pady=10)

        ctk.CTkButton(
            btns, text="View", width=80, height=36, corner_radius=18,
            fg_color=config.COLORS["primary"], hover_color=config.COLORS["primary_hover"],
            command=lambda e=entry: self._view_result(e),
        ).pack(side="left", padx=4)

        ctk.CTkButton(
            btns, text="🗑", width=44, height=36, corner_radius=18,
            fg_color="transparent", border_width=2, border_color=config.COLORS["danger"],
            text_color=config.COLORS["danger"], hover_color=config.COLORS["surface_dark"],
            command=lambda e=entry: self._delete_result(e),
        ).pack(side="left", padx=4)

    def _view_result(self, entry):
        self.controller.state_data.result = entry
        self.controller.state_data.viewing_history_id = entry["id"]
        self.controller.show_frame("results")

    def _delete_result(self, entry):
        confirm = messagebox.askyesno(
            "Delete Result", f"Delete this test result for {entry['user_name']}?"
        )
        if not confirm:
            return
        try:
            self.controller.db.delete_result(entry["id"])
        except DatabaseError as exc:
            messagebox.showerror("Database Error", str(exc))
            return
        self.on_show()

    def _go_back(self):
        if self.controller.state_data.result:
            self.controller.show_frame("results")
        else:
            self.controller.show_frame("welcome")
