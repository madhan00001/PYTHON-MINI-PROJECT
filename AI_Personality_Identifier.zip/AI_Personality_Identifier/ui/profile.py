"""ui/profile.py -- Screen 2: user name entry."""

import customtkinter as ctk
import config


class ProfileScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller

        center = ctk.CTkFrame(self, fg_color="transparent")
        center.place(relx=0.5, rely=0.5, anchor="center")

        icon = ctk.CTkLabel(center, text="👤", font=("Segoe UI Emoji", 48))
        icon.pack(pady=(0, 10))

        heading = ctk.CTkLabel(
            center, text="What's your name?", font=config.FONTS["heading"],
            text_color=config.COLORS["text_dark"],
        )
        heading.pack(pady=(0, 6))

        sub = ctk.CTkLabel(
            center, text="We'll personalize your entire experience.",
            font=config.FONTS["body"], text_color=config.COLORS["muted_dark"],
        )
        sub.pack(pady=(0, 24))

        self.name_var = ctk.StringVar()
        self.entry = ctk.CTkEntry(
            center, textvariable=self.name_var, width=340, height=48,
            corner_radius=14, font=config.FONTS["body"],
            placeholder_text="Enter your name...",
            fg_color=config.COLORS["surface_dark"], border_color=config.COLORS["border_dark"],
        )
        self.entry.pack(pady=(0, 8))
        self.entry.bind("<Return>", lambda e: self._continue())

        self.error_label = ctk.CTkLabel(
            center, text="", font=config.FONTS["small"], text_color=config.COLORS["danger"],
        )
        self.error_label.pack(pady=(0, 14))

        continue_btn = ctk.CTkButton(
            center, text="Continue  →", font=config.FONTS["button"],
            width=240, height=50, corner_radius=25,
            fg_color=config.COLORS["primary"], hover_color=config.COLORS["primary_hover"],
            command=self._continue,
        )
        continue_btn.pack()

        back_btn = ctk.CTkButton(
            self, text="← Back", font=config.FONTS["small"], width=90, height=34,
            corner_radius=17, fg_color="transparent",
            text_color=config.COLORS["muted_dark"], hover_color=config.COLORS["surface_dark"],
            command=lambda: controller.show_frame("welcome"),
        )
        back_btn.place(x=24, y=24)

    def on_show(self):
        self.name_var.set(self.controller.state_data.user_name)
        self.error_label.configure(text="")
        self.entry.focus_set()

    def _continue(self):
        name = self.name_var.get().strip()
        if not name:
            self.error_label.configure(text="⚠️ Please enter your name to continue.")
            return
        if len(name) > 40:
            self.error_label.configure(text="⚠️ Name is too long (max 40 characters).")
            return
        self.error_label.configure(text="")
        self.controller.state_data.user_name = name
        self.controller.show_frame("interests")
