"""ui/interests.py -- Screen 3: multi-select interest cards."""

import customtkinter as ctk
import config
from questions import INTERESTS


class InterestCard(ctk.CTkButton):
    """A toggleable card representing one interest."""

    def __init__(self, parent, interest, on_toggle):
        self.interest = interest
        self.selected = False
        self.on_toggle = on_toggle
        super().__init__(
            parent,
            text=f"{interest['emoji']}\n{interest['label']}",
            font=config.FONTS["body_bold"],
            width=150, height=100, corner_radius=18,
            fg_color=config.COLORS["surface_dark"],
            hover_color=config.COLORS["card_dark"],
            border_width=2, border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"],
            command=self._toggle,
        )

    def _toggle(self):
        self.selected = not self.selected
        self._refresh_style()
        self.on_toggle(self.interest["id"], self.selected)

    def _refresh_style(self):
        if self.selected:
            self.configure(
                fg_color=config.COLORS["primary"],
                border_color=config.COLORS["primary"],
                text_color="#ffffff",
            )
        else:
            self.configure(
                fg_color=config.COLORS["surface_dark"],
                border_color=config.COLORS["border_dark"],
                text_color=config.COLORS["text_dark"],
            )

    def set_selected(self, value: bool):
        self.selected = value
        self._refresh_style()


class InterestsScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller
        self.cards: dict[str, InterestCard] = {}
        self.selected_ids: set[str] = set()

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(pady=(36, 10))

        ctk.CTkLabel(
            header, text="🎯 Select the interests you enjoy",
            font=config.FONTS["heading"], text_color=config.COLORS["text_dark"],
        ).pack()
        ctk.CTkLabel(
            header, text="Choose as many as you like — this helps us tailor your results.",
            font=config.FONTS["body"], text_color=config.COLORS["muted_dark"],
        ).pack(pady=(4, 0))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent", width=760, height=380)
        scroll.pack(pady=10)

        columns = 5
        for idx, interest in enumerate(INTERESTS):
            row, col = divmod(idx, columns)
            card = InterestCard(scroll, interest, self._on_toggle)
            card.grid(row=row, column=col, padx=10, pady=10)
            self.cards[interest["id"]] = card

        self.error_label = ctk.CTkLabel(
            self, text="", font=config.FONTS["small"], text_color=config.COLORS["danger"],
        )
        self.error_label.pack(pady=(6, 0))

        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(pady=18)

        ctk.CTkButton(
            footer, text="← Back", font=config.FONTS["body"], width=120, height=46,
            corner_radius=23, fg_color="transparent", border_width=2,
            border_color=config.COLORS["border_dark"], text_color=config.COLORS["text_dark"],
            hover_color=config.COLORS["surface_dark"],
            command=lambda: controller.show_frame("profile"),
        ).pack(side="left", padx=8)

        ctk.CTkButton(
            footer, text="Continue  →", font=config.FONTS["button"], width=200, height=46,
            corner_radius=23, fg_color=config.COLORS["primary"],
            hover_color=config.COLORS["primary_hover"],
            command=self._continue,
        ).pack(side="left", padx=8)

    def on_show(self):
        state = self.controller.state_data
        self.selected_ids = set(state.interests)
        for interest_id, card in self.cards.items():
            card.set_selected(interest_id in self.selected_ids)
        self.error_label.configure(text="")

    def _on_toggle(self, interest_id, selected):
        if selected:
            self.selected_ids.add(interest_id)
        else:
            self.selected_ids.discard(interest_id)
        self.error_label.configure(text="")

    def _continue(self):
        if not self.selected_ids:
            self.error_label.configure(text="⚠️ Please select at least one interest to continue.")
            return
        self.controller.state_data.interests = list(self.selected_ids)
        self.controller.show_frame("quiz")
