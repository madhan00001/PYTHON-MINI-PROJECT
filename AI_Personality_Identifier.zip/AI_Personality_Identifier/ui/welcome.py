"""ui/welcome.py -- Screen 1: Welcome screen."""

import customtkinter as ctk
import config


class WelcomeScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller

        center = ctk.CTkFrame(self, fg_color="transparent")
        center.place(relx=0.5, rely=0.5, anchor="center")

        badge = ctk.CTkLabel(
            center, text="🤖", font=("Segoe UI Emoji", 64),
        )
        badge.pack(pady=(0, 10))

        title = ctk.CTkLabel(
            center, text="AI Personality Identifier",
            font=config.FONTS["title"], text_color=config.COLORS["text_dark"],
        )
        title.pack(pady=(0, 8))

        subtitle = ctk.CTkLabel(
            center,
            text="Discover your personality, interests, strengths and potential.",
            font=config.FONTS["subtitle"], text_color=config.COLORS["muted_dark"],
        )
        subtitle.pack(pady=(0, 36))

        start_btn = ctk.CTkButton(
            center, text="🚀  Get Started", font=config.FONTS["button"],
            width=240, height=52, corner_radius=26,
            fg_color=config.COLORS["primary"], hover_color=config.COLORS["primary_hover"],
            command=lambda: controller.start_new_test(),
        )
        start_btn.pack(pady=(0, 14))

        history_btn = ctk.CTkButton(
            center, text="📜  View Test History", font=config.FONTS["body"],
            width=240, height=44, corner_radius=22,
            fg_color="transparent", border_width=2,
            border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"],
            hover_color=config.COLORS["surface_dark"],
            command=lambda: controller.show_frame("history"),
        )
        history_btn.pack()

        version = ctk.CTkLabel(
            self, text=f"v{config.APP_VERSION}", font=config.FONTS["small"],
            text_color=config.COLORS["muted_dark"],
        )
        version.place(relx=0.98, rely=0.97, anchor="se")

    def on_show(self):
        pass
