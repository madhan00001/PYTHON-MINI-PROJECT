"""ui/chatbot_ui.py -- 'Ask AI about your personality' chat screen."""

import customtkinter as ctk
import config
from chatbot import Chatbot

SUGGESTIONS = [
    "What are my strengths?",
    "What career areas might suit my interests?",
    "How can I improve my communication?",
    "Why did I get this personality type?",
    "What activities might I enjoy?",
]


class ChatBubble(ctk.CTkFrame):
    def __init__(self, parent, text, is_user):
        align_color = config.COLORS["primary"] if is_user else config.COLORS["surface_dark"]
        text_color = "#ffffff" if is_user else config.COLORS["text_dark"]
        super().__init__(parent, fg_color="transparent")

        bubble = ctk.CTkLabel(
            self, text=text, font=config.FONTS["body"], text_color=text_color,
            fg_color=align_color, corner_radius=16, wraplength=520, justify="left",
            padx=16, pady=10,
        )
        bubble.pack(anchor="e" if is_user else "w", padx=10, pady=4)


class ChatbotScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller
        self.chatbot: Chatbot | None = None

        top_bar = ctk.CTkFrame(self, fg_color="transparent")
        top_bar.pack(fill="x", padx=30, pady=(24, 10))

        ctk.CTkButton(
            top_bar, text="← Back to Results", width=150, height=38, corner_radius=19,
            fg_color="transparent", border_width=2, border_color=config.COLORS["border_dark"],
            text_color=config.COLORS["text_dark"], hover_color=config.COLORS["surface_dark"],
            command=lambda: controller.show_frame("results"),
        ).pack(side="left")

        ctk.CTkLabel(
            top_bar, text="💬 Ask AI About Your Personality",
            font=config.FONTS["heading"], text_color=config.COLORS["text_dark"],
        ).pack(side="left", padx=20)

        self.chat_area = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.chat_area.pack(fill="both", expand=True, padx=30, pady=(0, 10))

        self.suggestions_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.suggestions_frame.pack(fill="x", padx=30, pady=(0, 8))

        input_row = ctk.CTkFrame(self, fg_color="transparent")
        input_row.pack(fill="x", padx=30, pady=(0, 24))

        self.entry_var = ctk.StringVar()
        self.entry = ctk.CTkEntry(
            input_row, textvariable=self.entry_var, height=48, corner_radius=24,
            font=config.FONTS["body"], placeholder_text="Ask something about your personality...",
            fg_color=config.COLORS["surface_dark"], border_color=config.COLORS["border_dark"],
        )
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.entry.bind("<Return>", lambda e: self._send())

        ctk.CTkButton(
            input_row, text="Send  ➤", width=110, height=48, corner_radius=24,
            fg_color=config.COLORS["primary"], hover_color=config.COLORS["primary_hover"],
            command=self._send,
        ).pack(side="left")

    # ------------------------------------------------------------------
    def on_show(self):
        result = self.controller.state_data.result
        if not result:
            self.controller.show_frame("welcome")
            return

        self.chatbot = Chatbot(result)

        for widget in self.chat_area.winfo_children():
            widget.destroy()
        for widget in self.suggestions_frame.winfo_children():
            widget.destroy()

        greeting = (
            f"Hi {result['user_name']}! I can answer questions about your "
            f"{result['personality_name']} result. What would you like to know?"
        )
        ChatBubble(self.chat_area, greeting, is_user=False).pack(fill="x")

        for suggestion in SUGGESTIONS:
            ctk.CTkButton(
                self.suggestions_frame, text=suggestion, font=config.FONTS["small"],
                height=32, corner_radius=16, fg_color=config.COLORS["surface_dark"],
                hover_color=config.COLORS["card_dark"], text_color=config.COLORS["muted_dark"],
                command=lambda s=suggestion: self._send(preset=s),
            ).pack(side="left", padx=4, pady=4)

    def _send(self, preset: str | None = None):
        question = preset if preset is not None else self.entry_var.get().strip()
        if not question:
            return

        ChatBubble(self.chat_area, question, is_user=True).pack(fill="x")
        self.entry_var.set("")

        answer = self.chatbot.ask(question) if self.chatbot else "Please start a test first."
        ChatBubble(self.chat_area, answer, is_user=False).pack(fill="x")

        self.after(50, lambda: self.chat_area._parent_canvas.yview_moveto(1.0))
