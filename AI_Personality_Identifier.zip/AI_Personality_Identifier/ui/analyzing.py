"""ui/analyzing.py -- Screen 5: animated 'AI is analyzing...' screen.

Runs the personality analysis engine, stores the result in the
database, then automatically advances to the results dashboard.
"""

import tkinter.messagebox as messagebox

import customtkinter as ctk
import config
from ai_analyzer import analyze
from database import DatabaseError

STEPS = [
    "🔎 Reading your answers...",
    "🧠 Calculating personality traits...",
    "🎯 Matching your interests...",
    "📊 Building your profile...",
    "✨ Finalizing your results...",
]


class AnalyzingScreen(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color=config.COLORS["bg_dark"])
        self.controller = controller
        self._step = 0
        self._after_id = None

        center = ctk.CTkFrame(self, fg_color="transparent")
        center.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(center, text="🤖", font=("Segoe UI Emoji", 56)).pack(pady=(0, 14))

        ctk.CTkLabel(
            center, text="AI is analyzing your personality...",
            font=config.FONTS["heading"], text_color=config.COLORS["text_dark"],
        ).pack(pady=(0, 22))

        self.progress = ctk.CTkProgressBar(
            center, width=420, height=12, corner_radius=6, mode="determinate",
            progress_color=config.COLORS["secondary"], fg_color=config.COLORS["surface_dark"],
        )
        self.progress.set(0)
        self.progress.pack(pady=(0, 14))

        self.step_label = ctk.CTkLabel(
            center, text=STEPS[0], font=config.FONTS["body"],
            text_color=config.COLORS["muted_dark"],
        )
        self.step_label.pack()

    # ------------------------------------------------------------------
    def on_show(self):
        self._step = 0
        self.progress.set(0)
        self.step_label.configure(text=STEPS[0])
        if self._after_id:
            self.after_cancel(self._after_id)
        self._after_id = self.after(450, self._animate_step)

    def _animate_step(self):
        self._step += 1
        progress_value = min(self._step / len(STEPS), 1.0)
        self.progress.set(progress_value)

        if self._step < len(STEPS):
            self.step_label.configure(text=STEPS[self._step])
            self._after_id = self.after(450, self._animate_step)
        else:
            self._after_id = self.after(400, self._finish_analysis)

    def _finish_analysis(self):
        state = self.controller.state_data
        try:
            result = analyze(state.user_name, state.interests, state.answers)
        except Exception as exc:
            messagebox.showerror(
                "Analysis Error",
                f"Something went wrong while analyzing your answers:\n{exc}",
            )
            self.controller.show_frame("quiz")
            return

        state.result = result

        if self.controller.db is not None:
            try:
                new_id = self.controller.db.save_result(result)
                result["id"] = new_id
            except DatabaseError as exc:
                messagebox.showwarning(
                    "Save Warning",
                    f"Your result could not be saved to history:\n{exc}\n\n"
                    "You can still view it now.",
                )

        state.viewing_history_id = result.get("id")
        self.controller.show_frame("results")
