"""
chatbot.py
----------
"Ask AI about your personality" follow-up chatbot.

If an external AI API key is configured (see config.py), the chatbot
sends the user's question plus their test-result context to the API
and returns the model's answer. If no API key is configured, or the
API call fails for any reason (no internet, invalid key, etc.), the
app falls back to a local rule-based chatbot so it keeps working
fully offline.
"""

import json
import urllib.request
import urllib.error

import config


class Chatbot:
    def __init__(self, result: dict):
        """result: a full analysis result dict, as produced by
        ai_analyzer.analyze() (or loaded from database history)."""
        self.result = result

    # ------------------------------------------------------------------
    def ask(self, question: str) -> str:
        question = (question or "").strip()
        if not question:
            return "Ask me anything about your personality result — for example, " \
                   "\"What are my strengths?\" or \"What career areas might suit me?\""

        if config.AI_PROVIDER == "anthropic" and config.ANTHROPIC_API_KEY:
            try:
                return self._ask_anthropic(question)
            except Exception:
                # Silent, graceful fallback -- app must never crash because
                # of a missing/failed external API call.
                pass

        if config.AI_PROVIDER == "openai" and config.OPENAI_API_KEY:
            try:
                return self._ask_openai(question)
            except Exception:
                pass

        return self._rule_based_answer(question)

    # ------------------------------------------------------------------
    def _context_summary(self) -> str:
        r = self.result
        scores_str = ", ".join(f"{k}: {v}%" for k, v in r["scores"].items())
        return (
            f"User: {r['user_name']}\n"
            f"Personality type: {r['personality_name']}\n"
            f"Trait scores: {scores_str}\n"
            f"Interests: {', '.join(r['interests'])}\n"
            f"Strengths: {', '.join(r['strengths'])}\n"
            f"Growth areas: {', '.join(r['growth_areas'])}\n"
            f"Recommended activities: {', '.join(r['recommendations'])}\n"
        )

    def _ask_anthropic(self, question: str) -> str:
        payload = {
            "model": config.AI_MODEL,
            "max_tokens": 400,
            "system": (
                "You are a friendly personality-insights assistant inside a desktop app. "
                "Answer the user's question about their AI-generated personality test result "
                "using the provided context. Keep answers warm, concise (under 150 words), "
                "and always remind the user this is an estimate, not a clinical diagnosis, "
                "if the question touches on mental health."
            ),
            "messages": [
                {
                    "role": "user",
                    "content": f"My personality context:\n{self._context_summary()}\n\nMy question: {question}",
                }
            ],
        }
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-api-key": config.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        parts = [block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"]
        text = "\n".join(p for p in parts if p).strip()
        return text or self._rule_based_answer(question)

    def _ask_openai(self, question: str) -> str:
        payload = {
            "model": "gpt-4o-mini",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are a friendly personality-insights assistant inside a desktop app. "
                        "Answer using the provided context, in under 150 words."
                    ),
                },
                {
                    "role": "user",
                    "content": f"My personality context:\n{self._context_summary()}\n\nMy question: {question}",
                },
            ],
            "max_tokens": 300,
        }
        req = urllib.request.Request(
            "https://api.openai.com/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {config.OPENAI_API_KEY}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        text = data["choices"][0]["message"]["content"].strip()
        return text or self._rule_based_answer(question)

    # ------------------------------------------------------------------
    def _rule_based_answer(self, question: str) -> str:
        """Local, offline fallback. Simple keyword matching against the
        result context -- always available, no external dependency."""
        q = question.lower()
        r = self.result

        if any(k in q for k in ["strength", "good at", "best at"]):
            return "Your key strengths are: " + ", ".join(r["strengths"]) + "."

        if any(k in q for k in ["weak", "improve", "growth", "work on"]):
            return "Areas you could grow in: " + ", ".join(r["growth_areas"]) + "."

        if any(k in q for k in ["career", "job", "work suit", "profession"]):
            return (
                "Based on your interests and personality type "
                f"({r['personality_name']}), you might enjoy: " + ", ".join(r["recommendations"]) + "."
            )

        if any(k in q for k in ["communicat", "social", "people"]):
            e_score = r["scores"].get("E", 50)
            a_score = r["scores"].get("A", 50)
            if e_score >= 60:
                return ("You're naturally outgoing (Extraversion "
                        f"{e_score}%), so lean into that in group settings. To sharpen "
                        "communication further, focus on active listening and giving others "
                        "space to speak.")
            return ("You score more reserved on Extraversion "
                    f"({e_score}%) with Agreeableness at {a_score}%. Try preparing a few "
                    "talking points before social situations, and remember that thoughtful "
                    "listeners are often the most trusted communicators.")

        if any(k in q for k in ["why", "personality type", "type"]):
            return (
                f"You were matched to {r['personality_name']} because your answers scored "
                "highest on the traits that define that type — you can see the exact "
                "percentages on your results dashboard. " + r["description"]
            )

        if any(k in q for k in ["activit", "hobby", "hobbies", "enjoy"]):
            return "You might enjoy: " + ", ".join(r["recommendations"]) + "."

        if any(k in q for k in ["interest"]):
            return "Your interests include: " + ", ".join(r["interests"]) + "."

        if any(k in q for k in ["score", "trait", "percentage"]):
            scores_str = "; ".join(f"{k}: {v}%" for k, v in r["scores"].items())
            return f"Here are your trait scores — {scores_str}."

        # Default fallback
        return (
            f"That's a great question! Based on your result ({r['personality_name']}), "
            "here's a quick summary: " + r["description"] +
            " Try asking about your strengths, growth areas, career fit, or communication style."
        )
