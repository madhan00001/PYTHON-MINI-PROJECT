"""
ai_analyzer.py
--------------
The "AI Analysis" layer. Combines the normalized trait scores from
personality_engine.py with the user's selected interests and
categorical tendencies to:

  - pick the closest-matching personality type
  - generate a personalized description
  - generate strengths and growth areas
  - generate activity recommendations
  - produce human-readable labels for decision style, social style,
    risk tolerance, motivation, work preference and learning style

This is a deterministic, explainable, rule-based "AI" analyzer.
It does not diagnose any medical or psychological condition -- it
produces an estimate for entertainment / self-reflection purposes,
clearly labeled as such throughout the UI and PDF report.
"""

import math

from questions import PERSONALITY_TYPES, INTEREST_ACTIVITIES, INTERESTS
from personality_engine import score_answers, TRAIT_KEYS, TRAIT_NAMES

INTEREST_LABELS = {i["id"]: f"{i['emoji']} {i['label']}" for i in INTERESTS}

TAG_LABELS = {
    "decision": {
        "analytical": "Analytical — you weigh facts and logic before deciding",
        "creative": "Creative — you look for original, out-of-the-box solutions",
        "collaborative": "Collaborative — you value input from others",
        "instinctive": "Instinctive — you trust your gut and act fast",
        "emotional": "Emotional — you follow how a decision feels",
        "methodical": "Methodical — you compare every option carefully",
    },
    "social_style": {
        "independent": "Independent — you enjoy your own company",
        "social": "Social — you draw energy from being with others",
        "outgoing": "Outgoing — you naturally take the lead in conversation",
        "balanced": "Balanced — you engage comfortably without forcing it",
        "reserved": "Reserved — you prefer to warm up gradually",
        "observant": "Observant — you like to understand a room before joining in",
    },
    "risk": {
        "comfortable": "Comfortable with change and uncertainty",
        "cautious": "Cautious — you prefer predictability",
        "calculated": "Calculated — you take risks only after weighing them",
        "high": "High risk tolerance — bold and adventurous",
        "moderate": "Moderate risk tolerance — open but careful",
        "low": "Low risk tolerance — you value safety and stability",
    },
    "motivation": {
        "achievement": "Achievement — success and accomplishment drive you",
        "security": "Security — stability and resources matter to you",
        "connection": "Connection — relationships are your biggest motivator",
        "growth": "Growth — learning and self-improvement drive you",
        "recognition": "Recognition — being seen and valued matters to you",
    },
    "work_pref": {
        "solo": "You do your best work independently",
        "small_team": "You thrive in small, close-knit teams",
        "large_team": "You enjoy the energy of larger teams",
        "flexible": "You adapt your working style to the task at hand",
        "team": "You enjoy collaborating with others",
    },
    "learning": {
        "self_study": "Self-directed learner who explores at your own pace",
        "structured": "You prefer structured, guided learning",
    },
}

# Extra strengths/growth areas keyed by dominant trait, used to add
# personalization beyond the base personality type template.
TRAIT_STRENGTHS = {
    "O": "Strong social connection and curiosity about new experiences",
    "C": "Well organized and dependable in following through on plans",
    "E": "Energetic and comfortable engaging with new people",
    "A": "Empathetic and easy to build trust with",
    "ES": "Stays composed and steady under pressure",
}

TRAIT_GROWTH = {
    "O": "Try turning big ideas into concrete, finished projects",
    "C": "Allow more room for spontaneity and flexibility",
    "E": "Carve out quiet time to recharge",
    "A": "Practice setting boundaries when needed",
    "ES": "Build small habits (journaling, reflection) to process stress",
}


def _closest_personality_type(scores: dict) -> str:
    """Find the personality type whose signature is closest (Euclidean
    distance) to the user's normalized trait scores."""
    best_type, best_distance = None, math.inf
    for type_id, data in PERSONALITY_TYPES.items():
        signature = data["signature"]
        distance = math.sqrt(
            sum((scores[t] - signature[t]) ** 2 for t in TRAIT_KEYS)
        )
        if distance < best_distance:
            best_distance = distance
            best_type = type_id
    return best_type


def _top_traits(scores: dict, n: int = 2) -> list[str]:
    return [t for t, _ in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:n]]


def analyze(user_name: str, interests: list[str], answers: dict[int, int]) -> dict:
    """
    Run the full analysis pipeline and return a result dict ready to
    be displayed, saved to the database, and exported to PDF.
    """
    engine_result = score_answers(answers)
    scores = engine_result["scores"]
    tags = engine_result["tags"]
    interest_hints = engine_result["interest_hints"]

    type_id = _closest_personality_type(scores)
    type_data = PERSONALITY_TYPES[type_id]

    top_traits = _top_traits(scores, n=2)

    # Strengths: base template + one personalized line from the top trait
    strengths = list(type_data["strengths"])
    for t in top_traits:
        line = TRAIT_STRENGTHS.get(t)
        if line and line not in strengths:
            strengths.append(line)

    # Growth areas: base template + a personalized line from the weakest trait
    weakest_trait = min(scores, key=lambda t: scores[t])
    growth_areas = list(type_data["growth_areas"])
    weak_line = TRAIT_GROWTH.get(weakest_trait)
    if weak_line and weak_line not in growth_areas:
        growth_areas.append(weak_line)

    # Merge explicit interests (chosen in Step 2) with hints inferred
    # from quiz answers, preserving order and removing duplicates.
    merged_interests = list(dict.fromkeys(interests + interest_hints))
    if not merged_interests:
        merged_interests = ["technology", "psychology"]

    recommendations = _build_recommendations(merged_interests, type_id)

    description = _build_description(user_name, type_data, scores, tags)

    profile_labels = _build_profile_labels(tags)

    return {
        "user_name": user_name,
        "interests": merged_interests,
        "answers": answers,
        "scores": scores,
        "personality_type": type_id,
        "personality_name": f"{type_data['emoji']} {type_data['name']}",
        "strengths": strengths,
        "growth_areas": growth_areas,
        "recommendations": recommendations,
        "description": description,
        "profile_labels": profile_labels,
    }


def _build_recommendations(interests: list[str], type_id: str, limit: int = 6) -> list[str]:
    recs: list[str] = []
    for interest in interests:
        for activity in INTEREST_ACTIVITIES.get(interest, []):
            if activity not in recs:
                recs.append(activity)
    if not recs:
        recs = ["Personal Development", "Skill Building", "Creative Projects"]
    return recs[:limit]


def _build_description(user_name: str, type_data: dict, scores: dict, tags: dict) -> str:
    top_trait = max(scores, key=lambda t: scores[t])
    top_trait_name = TRAIT_NAMES[top_trait]

    base = (
        f"{user_name}, based on your answers, you present as a "
        f"{type_data['name']}. {type_data['description']} "
        f"Your strongest measured trait is {top_trait_name} ({scores[top_trait]}%), "
        f"which shapes much of how you approach people, decisions and new experiences."
    )

    extra_bits = []
    if "decision" in tags:
        extra_bits.append(TAG_LABELS["decision"].get(tags["decision"], ""))
    if "social_style" in tags:
        extra_bits.append(TAG_LABELS["social_style"].get(tags["social_style"], ""))
    if "motivation" in tags:
        extra_bits.append(TAG_LABELS["motivation"].get(tags["motivation"], ""))

    extra_bits = [b for b in extra_bits if b]
    if extra_bits:
        base += " In particular: " + "; ".join(extra_bits) + "."

    base += (
        " This is an AI-generated estimate based on your quiz responses, "
        "not a clinical or psychological diagnosis."
    )
    return base


def _build_profile_labels(tags: dict) -> dict:
    """Human-readable labels for the categorical analyses shown on the
    result dashboard (decision-making style, social style, etc.)."""
    labels = {}
    for category, value in tags.items():
        labels[category] = TAG_LABELS.get(category, {}).get(value, value.replace("_", " ").title())
    return labels
