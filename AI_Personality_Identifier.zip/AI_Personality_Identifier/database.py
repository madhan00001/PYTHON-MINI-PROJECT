"""
database.py
------------
SQLite persistence layer for the AI Personality Identifier app.

Stores every completed test as a row containing the user's name,
selected interests, raw answers, computed trait scores, the assigned
personality type, strengths, growth areas, recommendations and a
timestamp. Provides simple helpers to save and retrieve history.
"""

import sqlite3
import json
import os
from datetime import datetime

import config


class DatabaseError(Exception):
    """Raised when a database operation fails."""


class DatabaseManager:
    def __init__(self, db_path: str = config.DATABASE_PATH):
        self.db_path = db_path
        try:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            self._init_db()
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to initialize database: {exc}") from exc

    # ------------------------------------------------------------------
    def _connect(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_name TEXT NOT NULL,
                    interests TEXT NOT NULL,
                    answers TEXT NOT NULL,
                    scores TEXT NOT NULL,
                    personality_type TEXT NOT NULL,
                    personality_name TEXT NOT NULL,
                    strengths TEXT NOT NULL,
                    growth_areas TEXT NOT NULL,
                    recommendations TEXT NOT NULL,
                    description TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.commit()

    # ------------------------------------------------------------------
    def save_result(self, result: dict) -> int:
        """Persist a completed test result. Returns the new row id."""
        try:
            with self._connect() as conn:
                cur = conn.execute(
                    """
                    INSERT INTO results (
                        user_name, interests, answers, scores, personality_type,
                        personality_name, strengths, growth_areas, recommendations,
                        description, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        result["user_name"],
                        json.dumps(result["interests"]),
                        json.dumps(result["answers"]),
                        json.dumps(result["scores"]),
                        result["personality_type"],
                        result["personality_name"],
                        json.dumps(result["strengths"]),
                        json.dumps(result["growth_areas"]),
                        json.dumps(result["recommendations"]),
                        result["description"],
                        result.get("created_at", datetime.now().isoformat(timespec="seconds")),
                    ),
                )
                conn.commit()
                return cur.lastrowid
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to save result: {exc}") from exc

    def get_history(self, user_name: str | None = None) -> list[dict]:
        """Return all saved results (optionally filtered by user), newest first."""
        try:
            with self._connect() as conn:
                if user_name:
                    rows = conn.execute(
                        "SELECT * FROM results WHERE user_name = ? ORDER BY id DESC",
                        (user_name,),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM results ORDER BY id DESC"
                    ).fetchall()
                return [self._row_to_dict(r) for r in rows]
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to fetch history: {exc}") from exc

    def get_result(self, result_id: int) -> dict | None:
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT * FROM results WHERE id = ?", (result_id,)
                ).fetchone()
                return self._row_to_dict(row) if row else None
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to fetch result: {exc}") from exc

    def get_previous_result(self, user_name: str, exclude_id: int | None = None) -> dict | None:
        """Return the most recent prior result for a user (for comparisons)."""
        try:
            with self._connect() as conn:
                if exclude_id:
                    row = conn.execute(
                        "SELECT * FROM results WHERE user_name = ? AND id != ? "
                        "ORDER BY id DESC LIMIT 1",
                        (user_name, exclude_id),
                    ).fetchone()
                else:
                    row = conn.execute(
                        "SELECT * FROM results WHERE user_name = ? ORDER BY id DESC LIMIT 1",
                        (user_name,),
                    ).fetchone()
                return self._row_to_dict(row) if row else None
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to fetch previous result: {exc}") from exc

    def delete_result(self, result_id: int) -> None:
        try:
            with self._connect() as conn:
                conn.execute("DELETE FROM results WHERE id = ?", (result_id,))
                conn.commit()
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to delete result: {exc}") from exc

    # ------------------------------------------------------------------
    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> dict:
        return {
            "id": row["id"],
            "user_name": row["user_name"],
            "interests": json.loads(row["interests"]),
            "answers": json.loads(row["answers"]),
            "scores": json.loads(row["scores"]),
            "personality_type": row["personality_type"],
            "personality_name": row["personality_name"],
            "strengths": json.loads(row["strengths"]),
            "growth_areas": json.loads(row["growth_areas"]),
            "recommendations": json.loads(row["recommendations"]),
            "description": row["description"],
            "created_at": row["created_at"],
        }
