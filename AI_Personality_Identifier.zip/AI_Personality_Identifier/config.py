"""
config.py
---------
Central configuration for the AI Personality Identifier app.
Holds paths, color palette, fonts, window settings and optional
external AI API configuration.
"""

import os

# ----------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_DIR = os.path.join(BASE_DIR, "database")
DATABASE_PATH = os.path.join(DATABASE_DIR, "personality.db")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

os.makedirs(DATABASE_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)

# ----------------------------------------------------------------------
# App info
# ----------------------------------------------------------------------
APP_NAME = "AI Personality Identifier"
APP_VERSION = "1.0.0"
WINDOW_WIDTH = 1000
WINDOW_HEIGHT = 700
MIN_WIDTH = 860
MIN_HEIGHT = 600

TOTAL_QUESTIONS = 15

# ----------------------------------------------------------------------
# Appearance
# ----------------------------------------------------------------------
APPEARANCE_MODE = "dark"          # "dark", "light", or "system"
COLOR_THEME = "blue"              # base CustomTkinter theme

# Custom color palette used throughout the UI
COLORS = {
    "bg_dark": "#0f1220",
    "bg_light": "#f4f6fb",
    "surface_dark": "#181c2e",
    "surface_light": "#ffffff",
    "card_dark": "#20253d",
    "card_light": "#eef1fa",
    "primary": "#7c6bf2",
    "primary_hover": "#6a58e0",
    "secondary": "#42e2b8",
    "accent": "#ff7ab6",
    "warning": "#ffb648",
    "danger": "#ff5c72",
    "text_dark": "#f3f4fb",
    "text_light": "#1c1f2e",
    "muted_dark": "#9aa0c3",
    "muted_light": "#666c85",
    "border_dark": "#2c3153",
    "border_light": "#dfe3f2",
}

FONT_FAMILY = "Segoe UI"          # falls back gracefully on other OSes
FONT_FAMILY_HEADING = "Segoe UI Semibold"

FONTS = {
    "title": (FONT_FAMILY_HEADING, 34, "bold"),
    "subtitle": (FONT_FAMILY, 16, "normal"),
    "heading": (FONT_FAMILY_HEADING, 24, "bold"),
    "subheading": (FONT_FAMILY_HEADING, 18, "bold"),
    "body": (FONT_FAMILY, 14, "normal"),
    "body_bold": (FONT_FAMILY, 14, "bold"),
    "small": (FONT_FAMILY, 12, "normal"),
    "button": (FONT_FAMILY, 15, "bold"),
    "badge": (FONT_FAMILY_HEADING, 20, "bold"),
}

# ----------------------------------------------------------------------
# Optional external AI API configuration (used by chatbot.py)
# ----------------------------------------------------------------------
# The app works fully offline with a rule-based chatbot fallback.
# To enable real AI-generated answers, set an environment variable
# before launching the app, e.g. (Windows PowerShell):
#     $env:ANTHROPIC_API_KEY = "sk-ant-..."
# or (macOS/Linux):
#     export ANTHROPIC_API_KEY="sk-ant-..."
AI_PROVIDER = os.environ.get("AI_PROVIDER", "none")        # "anthropic", "openai" or "none"
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
AI_MODEL = os.environ.get("AI_MODEL", "claude-sonnet-5")
