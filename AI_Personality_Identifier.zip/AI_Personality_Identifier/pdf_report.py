"""
pdf_report.py
-------------
Generates a professional PDF personality report using ReportLab.
"""

import os
import tempfile
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, Image,
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT

import config
from chart_utils import save_radar_png


class PDFReportError(Exception):
    """Raised when PDF generation fails."""


def _strip_emoji(text: str) -> str:
    """ReportLab's default fonts can't render emoji (they print as
    black boxes), so we strip non-Latin-1 characters for PDF text
    while keeping emoji everywhere else in the app (UI, chat, etc.)."""
    return "".join(ch for ch in text if ord(ch) < 256).strip(" -")


def _build_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="ReportTitle", fontSize=24, leading=28, alignment=TA_CENTER,
        textColor=colors.HexColor("#3a2f8f"), spaceAfter=6, fontName="Helvetica-Bold",
    ))
    styles.add(ParagraphStyle(
        name="ReportSubtitle", fontSize=12, leading=16, alignment=TA_CENTER,
        textColor=colors.HexColor("#555b7a"), spaceAfter=18,
    ))
    styles.add(ParagraphStyle(
        name="SectionHeading", fontSize=14, leading=18, spaceBefore=14, spaceAfter=8,
        textColor=colors.HexColor("#3a2f8f"), fontName="Helvetica-Bold",
    ))
    styles.add(ParagraphStyle(
        name="BodyJustify", fontSize=10.5, leading=15, alignment=TA_LEFT,
        textColor=colors.HexColor("#22243a"),
    ))
    styles.add(ParagraphStyle(
        name="BulletItem", fontSize=10.5, leading=15, leftIndent=14,
        textColor=colors.HexColor("#22243a"),
    ))
    styles.add(ParagraphStyle(
        name="Disclaimer", fontSize=8.5, leading=12, alignment=TA_CENTER,
        textColor=colors.HexColor("#888ea8"),
    ))
    return styles


def generate_pdf(result: dict, output_path: str | None = None) -> str:
    """
    Build a PDF personality report from a result dict (as produced by
    ai_analyzer.analyze()). Returns the path to the generated file.
    """
    try:
        os.makedirs(config.REPORTS_DIR, exist_ok=True)
        if output_path is None:
            safe_name = "".join(c for c in result["user_name"] if c.isalnum() or c in " _-").strip() or "user"
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(config.REPORTS_DIR, f"{safe_name}_{timestamp}.pdf")

        styles = _build_styles()
        doc = SimpleDocTemplate(
            output_path, pagesize=A4,
            topMargin=1.8 * cm, bottomMargin=1.6 * cm,
            leftMargin=2 * cm, rightMargin=2 * cm,
        )

        story = []
        story.append(Paragraph("AI Personality Identifier", styles["ReportTitle"]))
        story.append(Paragraph("Personalized Personality Report", styles["ReportSubtitle"]))
        story.append(HRFlowable(width="100%", color=colors.HexColor("#dcdff0"), thickness=1))
        story.append(Spacer(1, 12))

        meta_table = Table(
            [
                ["Name:", result["user_name"], "Date:", datetime.now().strftime("%d %B %Y, %H:%M")],
                ["Personality Type:", _strip_emoji(result["personality_name"]), "Interests:",
                 ", ".join(i.replace("_", " ").title() for i in result["interests"])],
            ],
            colWidths=[3.2 * cm, 5.3 * cm, 2.6 * cm, 5.4 * cm],
        )
        meta_table.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
            ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9.5),
            ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#22243a")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(meta_table)
        story.append(Spacer(1, 10))

        # ---- Personality description --------------------------------
        story.append(Paragraph("Personality Overview", styles["SectionHeading"]))
        story.append(Paragraph(result["description"], styles["BodyJustify"]))
        story.append(Spacer(1, 6))

        # ---- Trait scores table with simple bar visualization --------
        story.append(Paragraph("Personality Scores", styles["SectionHeading"]))
        trait_names = {
            "O": "Openness", "C": "Conscientiousness", "E": "Extraversion",
            "A": "Agreeableness", "ES": "Emotional Stability",
        }
        score_rows = [["Trait", "Score", "Visual"]]
        for key, label in trait_names.items():
            value = result["scores"].get(key, 0)
            bar_len = int(value / 100 * 30)
            bar = "█" * bar_len + "░" * (30 - bar_len)
            score_rows.append([label, f"{value}%", bar])

        score_table = Table(score_rows, colWidths=[5 * cm, 2 * cm, 9.5 * cm])
        score_table.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#efeafd")),
            ("FONTSIZE", (0, 0), (-1, -1), 9.5),
            ("FONTNAME", (2, 1), (2, -1), "Courier"),
            ("TEXTCOLOR", (2, 1), (2, -1), colors.HexColor("#7c6bf2")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#e4e6f5")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(score_table)
        story.append(Spacer(1, 10))

        # ---- Radar chart (Matplotlib) -----------------------------------
        chart_path = None
        try:
            chart_fd, chart_path = tempfile.mkstemp(suffix=".png")
            os.close(chart_fd)
            save_radar_png(result["scores"], chart_path, dark=False)
            story.append(Image(chart_path, width=8 * cm, height=8 * cm))
            story.append(Spacer(1, 10))
        except Exception:
            pass  # chart is a visual bonus -- report still generates without it

        # ---- Strengths -------------------------------------------------
        story.append(Paragraph("Strengths", styles["SectionHeading"]))
        for s in result["strengths"]:
            story.append(Paragraph(f"• {s}", styles["BulletItem"]))
        story.append(Spacer(1, 6))

        # ---- Growth areas ------------------------------------------------
        story.append(Paragraph("Growth Areas", styles["SectionHeading"]))
        for g in result["growth_areas"]:
            story.append(Paragraph(f"• {g}", styles["BulletItem"]))
        story.append(Spacer(1, 6))

        # ---- Recommendations --------------------------------------------
        story.append(Paragraph("Recommended Activities", styles["SectionHeading"]))
        for r in result["recommendations"]:
            story.append(Paragraph(f"• {r}", styles["BulletItem"]))
        story.append(Spacer(1, 14))

        story.append(HRFlowable(width="100%", color=colors.HexColor("#dcdff0"), thickness=1))
        story.append(Spacer(1, 8))
        story.append(Paragraph(
            "Disclaimer: This report is an AI-generated estimate based on your quiz "
            "responses. It is intended for self-reflection and entertainment purposes "
            "only, and is not a medical, clinical or psychological diagnosis.",
            styles["Disclaimer"],
        ))

        try:
            doc.build(story)
        finally:
            if chart_path and os.path.exists(chart_path):
                try:
                    os.remove(chart_path)
                except OSError:
                    pass

        return output_path

    except Exception as exc:
        raise PDFReportError(f"Failed to generate PDF report: {exc}") from exc
