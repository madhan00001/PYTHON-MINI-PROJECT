"""
personality_engine.py
----------------------
Turns the user's 15 raw answers into normalized Big-Five-style trait
scores (0-100) plus categorical tallies (decision style, social
style, risk tolerance, motivation, work preference, learning
preference, interest hints).

The algorithm:
1. Each answer option carries small integer trait deltas (see
   questions.py). We sum deltas per trait across all 15 answers.
2. Deltas are summed against a theoretical min/max range for that
   trait (computed from the question bank itself), then rescaled
   linearly to a 0-100 scale. This keeps the algorithm data-driven:
   if questions are added/edited, the ranges recompute automatically.
3. Categorical tags (e.g. "decision": "analytical") are simply
   counted; the most frequent tag per category wins.
"""

from collections import Counter
from questions import QUESTIONS

TRAIT_KEYS = ["O", "C", "E", "A", "ES"]

TRAIT_NAMES = {
    "O": "Openness",
    "C": "Conscientiousness",
    "E": "Extraversion",
    "A": "Agreeableness",
    "ES": "Emotional Stability",
}


def _theoretical_range(trait: str) -> tuple[int, int]:
    """Compute the min and max possible cumulative delta for a trait
    across all questions, assuming the most/least favorable option is
    picked each time. Used to normalize raw scores to 0-100."""
    min_total, max_total = 0, 0
    for q in QUESTIONS:
        deltas = [opt["traits"].get(trait, 0) for opt in q["options"]]
        min_total += min(deltas + [0])
        max_total += max(deltas + [0])
    # Guard against a degenerate zero-width range
    if max_total == min_total:
        max_total += 1
    return min_total, max_total


# Precompute ranges once at import time
_TRAIT_RANGES = {trait: _theoretical_range(trait) for trait in TRAIT_KEYS}


def score_answers(answers: dict[int, int]) -> dict:
    """
    answers: mapping of question_id -> selected option index

    Returns a dict:
        {
            "scores": {"O": 82, "C": 65, ...},       # 0-100 each
            "tags": {"decision": "analytical", ...}, # dominant categorical tags
            "interest_hints": ["technology", "travel", ...],
        }
    """
    raw_totals = {trait: 0 for trait in TRAIT_KEYS}
    tag_counters: dict[str, Counter] = {}
    interest_hint_counter = Counter()

    for q in QUESTIONS:
        idx = answers.get(q["id"])
        if idx is None or idx >= len(q["options"]):
            continue
        option = q["options"][idx]

        for trait, delta in option.get("traits", {}).items():
            raw_totals[trait] = raw_totals.get(trait, 0) + delta

        for tag_category, tag_value in option.get("tags", {}).items():
            if tag_category == "interest_hint":
                interest_hint_counter[tag_value] += 1
                continue
            tag_counters.setdefault(tag_category, Counter())[tag_value] += 1

    # Normalize each trait to 0-100 using the precomputed theoretical range
    scores = {}
    for trait in TRAIT_KEYS:
        raw = raw_totals[trait]
        low, high = _TRAIT_RANGES[trait]
        normalized = (raw - low) / (high - low) * 100
        scores[trait] = round(max(0, min(100, normalized)))

    dominant_tags = {
        category: counter.most_common(1)[0][0]
        for category, counter in tag_counters.items()
        if counter
    }

    interest_hints = [item for item, _ in interest_hint_counter.most_common()]

    return {
        "scores": scores,
        "tags": dominant_tags,
        "interest_hints": interest_hints,
    }
