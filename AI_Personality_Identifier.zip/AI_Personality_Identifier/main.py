"""
main.py
-------
Entry point for the AI Personality Identifier desktop app.

Sets up the CustomTkinter root window and a simple frame-based
navigation system, shared application state, and wires together the
database, analysis engine and PDF/report modules used by the
individual screens in ui/.
"""

import sys
import traceback
import tkinter as tk
import tkinter.messagebox as messagebox

import customtkinter as ctk

import config
from database import DatabaseManager, DatabaseError

from ui.welcome import WelcomeScreen
from ui.profile import ProfileScreen
from ui.interests import InterestsScreen
from ui.quiz import QuizScreen
from ui.analyzing import AnalyzingScreen
from ui.results import ResultsScreen
from ui.history import HistoryScreen
from ui.chatbot_ui import ChatbotScreen


class AppState:
    """Holds everything needed across screens for a single test run."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.user_name: str = ""
        self.interests: list[str] = []
        self.answers: dict[int, int] = {}
        self.current_question_index: int = 0
        self.result: dict | None = None
        self.viewing_history_id: int | None = None


class App(ctk.CTk):
    FRAME_ORDER = ("welcome", "profile", "interests", "quiz", "analyzing", "results", "history", "chatbot")

    def __init__(self):
        super().__init__()

        ctk.set_appearance_mode(config.APPEARANCE_MODE)
        ctk.set_default_color_theme(config.COLOR_THEME)

        self.title(config.APP_NAME)
        self.geometry(f"{config.WINDOW_WIDTH}x{config.WINDOW_HEIGHT}")
        self.minsize(config.MIN_WIDTH, config.MIN_HEIGHT)

        try:
            self.db = DatabaseManager()
        except DatabaseError as exc:
            messagebox.showerror("Database Error", str(exc))
            self.db = None

        self.state_data = AppState()

        # Container that holds every screen, stacked with grid so we can
        # raise whichever one should be visible ("card" navigation).
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.pack(fill="both", expand=True)
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        self.frames: dict[str, ctk.CTkFrame] = {}
        screen_classes = {
            "welcome": WelcomeScreen,
            "profile": ProfileScreen,
            "interests": InterestsScreen,
            "quiz": QuizScreen,
            "analyzing": AnalyzingScreen,
            "results": ResultsScreen,
            "history": HistoryScreen,
            "chatbot": ChatbotScreen,
        }

        for name, cls in screen_classes.items():
            frame = cls(parent=self.container, controller=self)
            self.frames[name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("welcome")
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ----------------------------------------------------------------
    def show_frame(self, name: str):
        frame = self.frames.get(name)
        if frame is None:
            return
        if hasattr(frame, "on_show"):
            try:
                frame.on_show()
            except Exception:
                traceback.print_exc()
        frame.tkraise()

    def start_new_test(self):
        """Reset app state and jump back to the name-entry screen."""
        self.state_data.reset()
        self.show_frame("profile")

    def _on_close(self):
        self.destroy()


def main():
    try:
        app = App()
        app.mainloop()
    except Exception as exc:  # pragma: no cover - top level safety net
        traceback.print_exc()
        try:
            messagebox.showerror(config.APP_NAME, f"A fatal error occurred:\n{exc}")
        except Exception:
            print(f"Fatal error: {exc}", file=sys.stderr)


if __name__ == "__main__":
    main()
