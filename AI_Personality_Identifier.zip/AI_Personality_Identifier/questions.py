"""
questions.py
------------
Static data used by the app: selectable interests, the 15
personality questions (with trait weights per option), and the
personality type catalogue used by the analysis engine.

Trait keys used throughout the scoring system:
    O  = Openness
    C  = Conscientiousness
    E  = Extraversion
    A  = Agreeableness
    ES = Emotional Stability

Each answer option carries a small dict of trait deltas plus
optional tags used for the categorical analyses (decision style,
social style, risk tolerance, motivation, work preference,
learning preference).
"""

# ----------------------------------------------------------------------
# Interests
# ----------------------------------------------------------------------
INTERESTS = [
    {"id": "technology", "emoji": "💻", "label": "Technology"},
    {"id": "art", "emoji": "🎨", "label": "Art & Design"},
    {"id": "music", "emoji": "🎵", "label": "Music"},
    {"id": "gaming", "emoji": "🎮", "label": "Gaming"},
    {"id": "reading", "emoji": "📚", "label": "Reading"},
    {"id": "sports", "emoji": "🏃", "label": "Sports"},
    {"id": "travel", "emoji": "✈️", "label": "Travel"},
    {"id": "movies", "emoji": "🎬", "label": "Movies"},
    {"id": "business", "emoji": "💼", "label": "Business"},
    {"id": "science", "emoji": "🔬", "label": "Science"},
    {"id": "photography", "emoji": "📸", "label": "Photography"},
    {"id": "writing", "emoji": "✍️", "label": "Writing"},
    {"id": "cooking", "emoji": "👨‍🍳", "label": "Cooking"},
    {"id": "nature", "emoji": "🌱", "label": "Nature"},
    {"id": "psychology", "emoji": "🧠", "label": "Psychology"},
]

# Interests -> recommended activities mapping
INTEREST_ACTIVITIES = {
    "technology": ["Software / App Development", "Technology Projects", "Hackathons"],
    "art": ["UI/UX Design", "Digital Illustration", "Creative Workshops"],
    "music": ["Music Production", "Learning an Instrument", "Podcasting"],
    "gaming": ["Game Design", "Esports Communities", "Game Development"],
    "reading": ["Book Clubs", "Content Curation", "Creative Writing"],
    "sports": ["Team Sports", "Fitness Coaching", "Sports Analytics"],
    "travel": ["Travel & Exploration", "Travel Blogging", "Cultural Exchange Programs"],
    "movies": ["Film Analysis", "Video Editing", "Content Creation"],
    "business": ["Startup Building", "Entrepreneurship", "Business Strategy"],
    "science": ["Research Projects", "STEM Communities", "Popular Science Writing"],
    "photography": ["Photography Projects", "Visual Storytelling", "Photo Editing"],
    "writing": ["Content Creation", "Blogging", "Creative Writing"],
    "cooking": ["Culinary Experiments", "Recipe Development", "Food Content Creation"],
    "nature": ["Outdoor Exploration", "Environmental Projects", "Gardening"],
    "psychology": ["Psychology Reading Groups", "Self-Development Coaching", "Human Behavior Research"],
}

# ----------------------------------------------------------------------
# Questions
# ----------------------------------------------------------------------
QUESTIONS = [
    {
        "id": 1,
        "text": "How do you usually spend your free time?",
        "options": [
            {"emoji": "🎮", "text": "Gaming", "traits": {"O": 2, "E": 0}, "tags": {"social_style": "independent"}},
            {"emoji": "📚", "text": "Reading", "traits": {"O": 3, "C": 1}, "tags": {"learning": "self_study"}},
            {"emoji": "🎵", "text": "Music", "traits": {"O": 2, "E": 1}, "tags": {}},
            {"emoji": "🏃", "text": "Sports", "traits": {"E": 2, "ES": 1}, "tags": {}},
            {"emoji": "👥", "text": "Spending time with friends", "traits": {"E": 3, "A": 2}, "tags": {"social_style": "social"}},
        ],
    },
    {
        "id": 2,
        "text": "When you're in a new group, you usually...",
        "options": [
            {"emoji": "🗣️", "text": "Start conversations", "traits": {"E": 3, "A": 1}, "tags": {"social_style": "outgoing"}},
            {"emoji": "🙂", "text": "Talk when someone approaches", "traits": {"E": 1, "A": 1}, "tags": {"social_style": "balanced"}},
            {"emoji": "🤐", "text": "Stay quiet initially", "traits": {"E": -2}, "tags": {"social_style": "reserved"}},
            {"emoji": "👀", "text": "Observe everyone first", "traits": {"O": 1, "E": -1}, "tags": {"social_style": "observant"}},
        ],
    },
    {
        "id": 3,
        "text": "When facing a difficult problem, you...",
        "options": [
            {"emoji": "🧠", "text": "Analyze it carefully", "traits": {"C": 3, "O": 1}, "tags": {"decision": "analytical"}},
            {"emoji": "💡", "text": "Try a creative solution", "traits": {"O": 3}, "tags": {"decision": "creative"}},
            {"emoji": "🤝", "text": "Ask someone for help", "traits": {"A": 2, "E": 1}, "tags": {"decision": "collaborative"}},
            {"emoji": "⚡", "text": "Try something immediately", "traits": {"E": 1, "C": -1}, "tags": {"decision": "instinctive"}},
        ],
    },
    {
        "id": 4,
        "text": "Which activity attracts you most?",
        "options": [
            {"emoji": "💻", "text": "Technology", "traits": {"O": 2, "C": 1}, "tags": {"interest_hint": "technology"}},
            {"emoji": "🎨", "text": "Art & Design", "traits": {"O": 3}, "tags": {"interest_hint": "art"}},
            {"emoji": "🔬", "text": "Science", "traits": {"O": 2, "C": 2}, "tags": {"interest_hint": "science"}},
            {"emoji": "💼", "text": "Business", "traits": {"C": 2, "E": 1}, "tags": {"interest_hint": "business"}},
            {"emoji": "🎬", "text": "Entertainment", "traits": {"E": 1, "O": 1}, "tags": {"interest_hint": "movies"}},
        ],
    },
    {
        "id": 5,
        "text": "How do you make important decisions?",
        "options": [
            {"emoji": "❤️", "text": "Follow feelings", "traits": {"A": 2, "ES": -1}, "tags": {"decision": "emotional"}},
            {"emoji": "🧠", "text": "Use logic", "traits": {"C": 3}, "tags": {"decision": "analytical"}},
            {"emoji": "👥", "text": "Ask others", "traits": {"A": 2, "E": 1}, "tags": {"decision": "collaborative"}},
            {"emoji": "⚖️", "text": "Compare everything first", "traits": {"C": 2, "O": 1}, "tags": {"decision": "methodical"}},
        ],
    },
    {
        "id": 6,
        "text": "Your ideal weekend is...",
        "options": [
            {"emoji": "🏠", "text": "Relaxing at home", "traits": {"E": -2, "ES": 1}, "tags": {"work_pref": "solo"}},
            {"emoji": "🥳", "text": "Going out with friends", "traits": {"E": 3, "A": 1}, "tags": {"work_pref": "team"}},
            {"emoji": "✈️", "text": "Exploring somewhere new", "traits": {"O": 3, "E": 1}, "tags": {"interest_hint": "travel"}},
            {"emoji": "🎮", "text": "Gaming / watching movies", "traits": {"O": 1, "E": -1}, "tags": {"interest_hint": "gaming"}},
        ],
    },
    {
        "id": 7,
        "text": "How do you react when plans suddenly change?",
        "options": [
            {"emoji": "😎", "text": "I adapt easily", "traits": {"ES": 3, "O": 1}, "tags": {"risk": "comfortable"}},
            {"emoji": "😟", "text": "I feel uncomfortable", "traits": {"ES": -3}, "tags": {"risk": "cautious"}},
            {"emoji": "🧠", "text": "I make a new plan", "traits": {"C": 2, "ES": 1}, "tags": {"risk": "calculated"}},
            {"emoji": "🤷", "text": "I just go with the flow", "traits": {"O": 1, "C": -1}, "tags": {"risk": "comfortable"}},
        ],
    },
    {
        "id": 8,
        "text": "Do you prefer working...",
        "options": [
            {"emoji": "👤", "text": "Completely alone", "traits": {"E": -2, "C": 1}, "tags": {"work_pref": "solo"}},
            {"emoji": "👥", "text": "With a small team", "traits": {"E": 1, "A": 2}, "tags": {"work_pref": "small_team"}},
            {"emoji": "🏢", "text": "With a large team", "traits": {"E": 2, "A": 1}, "tags": {"work_pref": "large_team"}},
            {"emoji": "🔄", "text": "Depends on the task", "traits": {"O": 2}, "tags": {"work_pref": "flexible"}},
        ],
    },
    {
        "id": 9,
        "text": "How comfortable are you with taking risks?",
        "options": [
            {"emoji": "🚀", "text": "Very comfortable", "traits": {"O": 2, "ES": 2}, "tags": {"risk": "high"}},
            {"emoji": "🙂", "text": "Somewhat comfortable", "traits": {"ES": 1}, "tags": {"risk": "moderate"}},
            {"emoji": "⚖️", "text": "I consider the risks carefully", "traits": {"C": 2}, "tags": {"risk": "calculated"}},
            {"emoji": "🛑", "text": "I prefer safe choices", "traits": {"C": 1, "ES": -1}, "tags": {"risk": "low"}},
        ],
    },
    {
        "id": 10,
        "text": "What motivates you the most?",
        "options": [
            {"emoji": "🏆", "text": "Success", "traits": {"C": 2, "E": 1}, "tags": {"motivation": "achievement"}},
            {"emoji": "💰", "text": "Money", "traits": {"C": 1}, "tags": {"motivation": "security"}},
            {"emoji": "❤️", "text": "Relationships", "traits": {"A": 3}, "tags": {"motivation": "connection"}},
            {"emoji": "🧠", "text": "Learning", "traits": {"O": 3}, "tags": {"motivation": "growth"}},
            {"emoji": "🌟", "text": "Recognition", "traits": {"E": 2}, "tags": {"motivation": "recognition"}},
        ],
    },
    {
        "id": 11,
        "text": "When someone criticizes you, you usually...",
        "options": [
            {"emoji": "🧠", "text": "Learn from it", "traits": {"O": 2, "ES": 2}, "tags": {}},
            {"emoji": "😔", "text": "Take it personally", "traits": {"ES": -3}, "tags": {}},
            {"emoji": "💬", "text": "Discuss it with them", "traits": {"A": 2, "E": 1}, "tags": {}},
            {"emoji": "😎", "text": "Ignore it", "traits": {"ES": 1, "A": -1}, "tags": {}},
        ],
    },
    {
        "id": 12,
        "text": "Which describes you best?",
        "options": [
            {"emoji": "🎯", "text": "Organized", "traits": {"C": 3}, "tags": {}},
            {"emoji": "🌊", "text": "Flexible", "traits": {"O": 2, "C": -1}, "tags": {}},
            {"emoji": "🔥", "text": "Ambitious", "traits": {"C": 2, "E": 2}, "tags": {"motivation": "achievement"}},
            {"emoji": "🌱", "text": "Calm", "traits": {"ES": 3}, "tags": {}},
        ],
    },
    {
        "id": 13,
        "text": "What type of content do you enjoy most?",
        "options": [
            {"emoji": "🎓", "text": "Educational", "traits": {"O": 2, "C": 1}, "tags": {"learning": "structured"}},
            {"emoji": "😂", "text": "Entertainment", "traits": {"E": 1}, "tags": {}},
            {"emoji": "💡", "text": "Technology", "traits": {"O": 2}, "tags": {"interest_hint": "technology"}},
            {"emoji": "❤️", "text": "Emotional / inspirational", "traits": {"A": 2}, "tags": {}},
            {"emoji": "🌍", "text": "Travel / lifestyle", "traits": {"O": 1, "E": 1}, "tags": {"interest_hint": "travel"}},
        ],
    },
    {
        "id": 14,
        "text": "If you had one completely free month, what would you choose?",
        "options": [
            {"emoji": "✈️", "text": "Travel", "traits": {"O": 3}, "tags": {"interest_hint": "travel"}},
            {"emoji": "📚", "text": "Learn something new", "traits": {"O": 2, "C": 1}, "tags": {"learning": "self_study"}},
            {"emoji": "🎮", "text": "Entertainment", "traits": {"E": -1}, "tags": {}},
            {"emoji": "💼", "text": "Build a project/business", "traits": {"C": 3, "E": 1}, "tags": {"motivation": "achievement"}},
            {"emoji": "🧘", "text": "Relax and enjoy life", "traits": {"ES": 2}, "tags": {}},
        ],
    },
    {
        "id": 15,
        "text": "Which statement best describes your future goal?",
        "options": [
            {"emoji": "🏆", "text": "I want to become highly successful", "traits": {"C": 2, "E": 1}, "tags": {"motivation": "achievement"}},
            {"emoji": "💡", "text": "I want to create something meaningful", "traits": {"O": 3}, "tags": {"motivation": "growth"}},
            {"emoji": "❤️", "text": "I want a happy and peaceful life", "traits": {"A": 2, "ES": 2}, "tags": {"motivation": "connection"}},
            {"emoji": "🌍", "text": "I want to explore the world", "traits": {"O": 2, "E": 1}, "tags": {"interest_hint": "travel"}},
            {"emoji": "🧠", "text": "I want to continuously learn and grow", "traits": {"O": 2, "C": 1}, "tags": {"motivation": "growth"}},
        ],
    },
]

# ----------------------------------------------------------------------
# Personality type catalogue
# ----------------------------------------------------------------------
# Each type has an ideal trait "signature" (0-100 scale) used to find
# the closest match via distance calculation, plus display content.
PERSONALITY_TYPES = {
    "creative_explorer": {
        "name": "Creative Explorer",
        "emoji": "🌟",
        "signature": {"O": 85, "C": 55, "E": 65, "A": 70, "ES": 60},
        "description": (
            "You are driven by curiosity and imagination. You love discovering new ideas, "
            "places and experiences, and you bring a creative spark to everything you do. "
            "You thrive when you have freedom to explore and experiment."
        ),
        "strengths": ["Creative thinker", "Curious about new things", "Adaptable", "Open-minded"],
        "growth_areas": ["Can lose focus when juggling too many ideas", "May benefit from more structure and follow-through"],
    },
    "analytical_thinker": {
        "name": "Analytical Thinker",
        "emoji": "🧠",
        "signature": {"O": 65, "C": 85, "E": 35, "A": 50, "ES": 65},
        "description": (
            "You approach life logically and methodically. You enjoy breaking down complex "
            "problems, spotting patterns, and making well-reasoned decisions. Precision and "
            "clarity matter to you."
        ),
        "strengths": ["Strong problem solver", "Detail-oriented", "Logical decision-maker", "Reliable"],
        "growth_areas": ["May overthink decisions", "Could benefit from trusting intuition more often"],
    },
    "ambitious_leader": {
        "name": "Ambitious Leader",
        "emoji": "🚀",
        "signature": {"O": 60, "C": 80, "E": 80, "A": 50, "ES": 70},
        "description": (
            "You are goal-driven and confident, with a natural ability to take charge. You "
            "set high standards for yourself and inspire momentum in the people around you."
        ),
        "strengths": ["Goal-oriented", "Confident communicator", "Decisive", "Resilient under pressure"],
        "growth_areas": ["May come across as impatient", "Could work on active listening and delegation"],
    },
    "social_connector": {
        "name": "Social Connector",
        "emoji": "🤝",
        "signature": {"O": 60, "C": 55, "E": 85, "A": 85, "ES": 65},
        "description": (
            "You build genuine connections wherever you go. Warm, empathetic and outgoing, "
            "you energize the people around you and create a strong sense of community."
        ),
        "strengths": ["Excellent communicator", "Empathetic", "Team-builder", "Great at networking"],
        "growth_areas": ["May prioritize others' needs over your own", "Could work on solo focus time"],
    },
    "calm_strategist": {
        "name": "Calm Strategist",
        "emoji": "🌱",
        "signature": {"O": 55, "C": 75, "E": 35, "A": 65, "ES": 85},
        "description": (
            "You bring steadiness and thoughtful planning to everything you do. Calm under "
            "pressure, you prefer well-considered decisions over impulsive ones and value "
            "long-term stability."
        ),
        "strengths": ["Emotionally stable", "Thoughtful planner", "Dependable", "Great under pressure"],
        "growth_areas": ["May be slow to embrace sudden change", "Could push out of the comfort zone more often"],
    },
    "imaginative_creator": {
        "name": "Imaginative Creator",
        "emoji": "🎨",
        "signature": {"O": 90, "C": 50, "E": 50, "A": 60, "ES": 55},
        "description": (
            "You see the world differently and love bringing original ideas to life. Artistic "
            "and expressive, you are most fulfilled when creating something new."
        ),
        "strengths": ["Highly original", "Expressive", "Visionary", "Comfortable with ambiguity"],
        "growth_areas": ["May struggle with repetitive tasks", "Could benefit from finishing what you start"],
    },
    "curious_scientist": {
        "name": "Curious Scientist",
        "emoji": "🔬",
        "signature": {"O": 80, "C": 75, "E": 40, "A": 50, "ES": 65},
        "description": (
            "You are endlessly curious about how things work. Methodical yet imaginative, "
            "you enjoy research, experimentation and continuous learning."
        ),
        "strengths": ["Analytical curiosity", "Persistent researcher", "Objective thinker", "Detail-focused"],
        "growth_areas": ["May get lost in details", "Could work on communicating findings simply"],
    },
    "innovative_problem_solver": {
        "name": "Innovative Problem Solver",
        "emoji": "💡",
        "signature": {"O": 80, "C": 70, "E": 55, "A": 55, "ES": 70},
        "description": (
            "You combine creativity with practicality, always looking for smarter ways to "
            "solve problems. You are resourceful, adaptable, and unafraid of a challenge."
        ),
        "strengths": ["Resourceful", "Creative problem solver", "Adaptable", "Quick learner"],
        "growth_areas": ["May jump between ideas too quickly", "Could benefit from deeper follow-through"],
    },
}
